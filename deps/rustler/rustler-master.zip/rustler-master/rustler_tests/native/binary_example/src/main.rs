fn main() {
    println!("Hello from Rust!");
}
