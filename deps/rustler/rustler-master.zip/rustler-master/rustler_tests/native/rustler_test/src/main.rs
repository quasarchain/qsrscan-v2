fn main() {
    println!("Hello Rust!");
}
