#[rustler::nif(name = "nif_attrs_can_rename")]
pub fn can_rename() -> bool {
    true
}
