#!/bin/sh

escript gen_api.erl 4 precompiled/nif_api.4.snippet
escript gen_api.erl 8 precompiled/nif_api.8.snippet
