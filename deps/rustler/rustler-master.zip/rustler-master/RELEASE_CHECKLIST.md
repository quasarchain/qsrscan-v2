1. Bump rustler, rustler_codegen, rustler_mix (including lib/rustler.ex), installer template version numbers
2. Publish crates, rustler_mix, installer
3. Update documentation
